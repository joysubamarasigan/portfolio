# SinglePro v1
Onepage, Responsive Bootstrap business & portfolio template. Wordpress version also available. Have a look at [Demo](http://www.wpfreeware.com/singlepro-free-bootstrap-one-page-business-portfolio-theme/) hosted at [WpFreeware](http://wpfreeware.net/).

## Instructions
    - Customize as your need.
    - Upload to a web server via ftp.

## Color variation usage
SinglePro has 10 different pre-defined color variations, although it has unlimited color possibilities. See help file in the downloaded folder to change template color scheme. 

## Contact us:
If you have any further question regarding this template then feel free to leave a comment in the template download page.

Thank You
(http://www.wpfreeware.com/)
